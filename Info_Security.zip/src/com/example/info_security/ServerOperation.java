package com.example.info_security;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.lang.ref.WeakReference;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.ByteArrayBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.tsccm.ThreadSafeClientConnManager;
import org.apache.http.params.HttpParams;
import org.apache.http.protocol.HTTP;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.ImageView;

public class ServerOperation {

	private DefaultHttpClient httpClient;
	private static String server = "http://143.248.249.217:3000";
	private static String storageDir = "/_image_cache_";
	private static int imageMaxSize = 200;
	
	
	public String getServerUrl() {
		return server;
	}

	public DefaultHttpClient getThreadSafeClient() {
		if (httpClient != null)
			return httpClient;
		httpClient = new DefaultHttpClient();
		ClientConnectionManager mgr = httpClient.getConnectionManager();
		HttpParams params = httpClient.getParams();
		httpClient = new DefaultHttpClient(new ThreadSafeClientConnManager(params,
				mgr.getSchemeRegistry()), params);
		return httpClient;
	}
	
	public JSONObject getJSONFromUrl(
			String url,
			String requestMethod,
			List<NameValuePair> params,
			byte[] file) {
		httpClient = getThreadSafeClient();
		
		InputStream is = null;
		JSONObject jObj = null;
		String json = "";
		url = server + url;
		
		// Making HTTP request
		try {
			HttpResponse httpResponse = null;
			
			// HTTP GET
			if (requestMethod.equals("GET")) {
				if (params != null)
					url += "?" + URLEncodedUtils.format(params, "utf-8");
				HttpGet httpGet = new HttpGet(url);
				httpResponse = httpClient.execute(httpGet);
			}
			// HTTP POST
			else if (requestMethod.equals("POST")) {
				HttpPost httpPost = new HttpPost(url);
				if (params != null) {
					UrlEncodedFormEntity entity = new UrlEncodedFormEntity(params, HTTP.UTF_8);
					httpPost.setEntity(entity);
				}
				httpResponse = httpClient.execute(httpPost);
			}
			// HTTP PUT
			else if (requestMethod.equals("PUT")) {
				HttpPut httpPut = new HttpPut(url);
				if (params != null) {
					UrlEncodedFormEntity entity = new UrlEncodedFormEntity(params, HTTP.UTF_8);
					httpPut.setEntity(entity);
				}
				httpResponse = httpClient.execute(httpPut);
			}
			// HTTP DELETE
			else if (requestMethod.equals("DELETE")) {
				HttpDelete httpDelete = new HttpDelete(url);
				httpResponse = httpClient.execute(httpDelete);
			}
			// HTTP PUT with file
			else if (requestMethod.equals("FILE")) {
				HttpPut httpPut = new HttpPut(url);
				MultipartEntity entity = new MultipartEntity(HttpMultipartMode.BROWSER_COMPATIBLE);
				ByteArrayBody bab = new ByteArrayBody(file, "image.jpg");
				entity.addPart("user[image]", bab);
				httpPut.setEntity(entity);
				httpResponse = httpClient.execute(httpPut);
			}
			
			HttpEntity httpEntity = httpResponse.getEntity();
			is = httpEntity.getContent();
			
			try {
				BufferedReader reader = new BufferedReader(new InputStreamReader(is));
				
				StringBuilder sb = new StringBuilder();
				String line = null;
				while ((line = reader.readLine()) != null) {
					sb.append(line + "\n");
				}
				is.close();
				reader.close();
				json = sb.toString();
				httpEntity.consumeContent();
				
				// try parse the string to a JSON object
				try {
					jObj = new JSONObject(json);
					
					// return JSON string
					return jObj;
				}
				catch (JSONException e) {
					e.printStackTrace();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		catch (ClientProtocolException e) {
			e.printStackTrace();
		}
		catch (IOException e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public Bitmap decodeBitmapFile(String url, Context activityContext) {
		File imageFile = new File(activityContext.getCacheDir().getAbsolutePath() + storageDir, url);
		if (imageFile.exists()) {
			BitmapFactory.Options options = new BitmapFactory.Options();
			options.inJustDecodeBounds = true;
			BitmapFactory.decodeFile(imageFile.getAbsolutePath(), options);
			
			int scale = 1;
			while (options.outWidth / scale / 2 >= imageMaxSize &&
					options.outHeight / scale / 2 >= imageMaxSize) {
				scale *= 2;
			}
			
			options.inSampleSize = scale;
			options.inJustDecodeBounds = false;
			options.inDither = true;
			
			return BitmapFactory.decodeFile(imageFile.getAbsolutePath(), options);
		}
		
		return null;
	}
	
	public void getImage(String url, ImageView imageView, Context activityContext) {
		new GetImage(url, imageView, activityContext).execute();
	}
	
	// AsyncTask<Params, Progress, Result>
	private class GetImage extends AsyncTask<Void, Void, Bitmap> {
		
		private String url;
		private WeakReference<ImageView> imageViewReference;
		private Context activityContext;
		private int width;
		private int height;
		
		public GetImage(String url, ImageView imageView, Context activityContext) {
			this.url = url;
			this.imageViewReference = new WeakReference<ImageView>(imageView);
			this.activityContext = activityContext;
			if (httpClient == null)
				httpClient = getThreadSafeClient();
		}
		
		@Override
		protected Bitmap doInBackground(Void... params) {
			if (url == null || url.equals(""))
				return null;
			
			Bitmap bitmap = decodeBitmapFile(url, activityContext);
			
			if (bitmap != null)
				return bitmap;
			
			HttpGet httpGet = new HttpGet(server + url);
			try {
				HttpResponse httpResponse = httpClient.execute(httpGet);
				HttpEntity httpEntity = httpResponse.getEntity();
				InputStream is = httpEntity.getContent();
				
				File file = new File(activityContext.getCacheDir().getAbsolutePath() + storageDir, url);
				if (!file.getParentFile().exists())
					file.getParentFile().mkdirs();
				file.createNewFile();
				FileOutputStream fileOutput = new FileOutputStream(file);
				FlushedInputStream fis = new FlushedInputStream(is);
				byte[] buffer = new byte[1024];
				int bufferLength = 0;
				
				while ((bufferLength = fis.read(buffer)) > 0)
					fileOutput.write(buffer, 0, bufferLength);
				
				fileOutput.flush();
				fileOutput.close();
				
				if (is != null)
					is.close();
				httpEntity.consumeContent();
				
				return decodeBitmapFile(url, activityContext);
			} catch (ClientProtocolException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return null;
		}
		
		@Override
		protected void onPostExecute(Bitmap bitmap) {
			if (bitmap != null && imageViewReference != null) {
				ImageView imageView = imageViewReference.get();
				if (imageView != null && imageView.getWidth()==0)
					imageView.setImageBitmap(bitmap);
				else if(imageView !=null && imageView.getWidth()>0){
					imageView.setImageBitmap(getRoundedBitmap(bitmap));
				}
			}
		}
		protected Bitmap getRoundedBitmap(Bitmap bitmap) {
	        if(bitmap != null){
	        	Bitmap myBitmap = Bitmap.createScaledBitmap(bitmap, imageViewReference.get().getWidth(),
	        			imageViewReference.get().getHeight() , true);
	            Bitmap output = Bitmap.createBitmap(myBitmap.getWidth(), myBitmap.getHeight(), Config.ARGB_8888);

	 	       Canvas canvas = new Canvas(output);

	 	       final int color = 0xff424242;

	 	       final Paint paint = new Paint();

	 	       final Rect rect = new Rect(0, 0, myBitmap.getWidth(), myBitmap.getHeight());

	 	       final RectF rectF = new RectF(rect);

	 	       final float roundPx = 12;

	 	       paint.setAntiAlias(true);

	 	       canvas.drawARGB(0, 0, 0, 0);
	 	       
	 	       paint.setColor(color);
	 	       
	 	       canvas.drawRoundRect(rectF, roundPx, roundPx, paint);
	 	       
	 	       paint.setXfermode(new PorterDuffXfermode(Mode.SRC_IN));
	 	       
	 	       canvas.drawBitmap(myBitmap, rect, rect, paint);

	 	       return output;
	        }
	        return bitmap;
	    }
	}
	
	static class FlushedInputStream extends FilterInputStream {
		
		public FlushedInputStream(InputStream inputStream) {
			super(inputStream);
		}
		
		@Override
		public long skip(long n) throws IOException {
			long totalBytesSkipped = 0L;
			while (totalBytesSkipped < n) {
				long bytesSkipped = in.skip(n - totalBytesSkipped);
				if (bytesSkipped == 0L) {
					int bytes = read();
					if (bytes < 0)
						break;
					else
						bytesSkipped = 1;
				}
				totalBytesSkipped += bytesSkipped;
			}
			
			return totalBytesSkipped;
		}
	}}
