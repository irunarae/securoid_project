package com.example.info_security;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import android.util.Log;

public class Server {
 String xml;
 
 public void connect() {
        
  StringBuffer sBuffer = new StringBuffer();
  try {
   String urlAddr = "http://������ �� ȣ���� �ּ� �� ���� �ּ� ����/data.xml";
   //���� ����Ʈ���� ������ ��ȣ���� �ּҳ� ���� �ּҸ� �����ð� �ڿ� data.xml �����ñ� �ٶ��ϴ�.
   URL url = new URL(urlAddr);
   HttpURLConnection conn = (HttpURLConnection)url.openConnection();
   if(conn != null) {
    conn.setConnectTimeout(20000);
    conn.setUseCaches(false);
    if(conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
     InputStreamReader isr = new InputStreamReader(conn.getInputStream());
     BufferedReader br = new BufferedReader(isr);
     while(true) {
      String line = br.readLine();
      if(line == null) {
       break;
      }
      sBuffer.append(line);
     }
     br.close();
     conn.disconnect();
    }
   }
   xml = sBuffer.toString();
  } catch(Exception e) {
   Log.e("�ٿ�ε� �� ���� �߻�", e.getMessage());
  }
  parse();
}
 public void parse() {
  try {
   DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
   DocumentBuilder documentBuilder = factory.newDocumentBuilder();
   InputStream is = new ByteArrayInputStream(xml.getBytes());
   Document doc = documentBuilder.parse(is);
   doc.getDocumentElement().normalize();
   
   NodeList headline_node_list = doc.getElementsByTagName("menu");
   String name = "", best = "";
   String text = "";
   
   for(int i = 0;i<headline_node_list.getLength(); i++) {
    Node headline_node = headline_node_list.item(i);
    if(headline_node.getNodeType() == Node.ELEMENT_NODE) {
     Element element = (Element) headline_node;
     NodeList node_list = element.getElementsByTagName("name");
     Node node = node_list.item(0);
     name = node.getTextContent();
    }
    if(headline_node.getNodeType() == Node.ELEMENT_NODE) {
     Element element = (Element) headline_node;
     NodeList node_list = element.getElementsByTagName("best");
     Node node = node_list.item(0);
     best = node.getTextContent();
    }
    text += (name + "    " + best +"\n");
   }

   } catch(Exception e) {
    Log.e("�Ľ� �� ���� �߻�", e.getMessage());
   }
 }  
}


